# Protocole de faisabilité — avant toute requête LLM

29 octobre. Variante du vérificateur : ref `refs/codex/verificateur-strict-29`, premier commit 77c7d95e. Référence harnais : copie du RO préparé par E1, SHA exact à inscrire dans le manifeste avant requête. Ne pas employer le carnet Kaggle vivant. Claude gère infrastructure et extinction, plafond global 100 euros ; premier lot plafonné à 4 heures de location, installation comprise, sauf nouvelle décision explicite. Le tarif effectif est vérifié par Claude, pas déduit des tarifs historiques.

## Étape 1 : vérifier une capacité, pas annoncer un score ARC

Une seule trace publique de développement déjà acquise, sk48 N1, SHA NPZ f74eca114e4f70028ad1ab381b16f869647505144e689973ce852bad257f8043. Le jeu est connu de l'équipe : aucun qualificatif de jeu tenu à l'écart ou de généralisation. Zéro nouvelle initialisation SDK.

Deux fenêtres fixées avant appel :

- A : images 0 à 11 et actions 1 à 11 montrées au modèle ; actions 12 à 23 évaluées ensuite sans montrer leurs résultats au modèle.
- B : images 82 à 93 et actions 83 à 93 montrées au modèle ; actions 94 à 105 évaluées ensuite sans montrer leurs résultats au modèle.

Chaque fenêtre fournit des images finales et actions telles qu'enregistrées. On ne dit pas que les films sont disponibles dans cette entrée. Ne pas masquer des cellules à partir des réponses futures. Les images des fenêtres/suffixes ont déjà été consultées par l'équipe ; le suffixe est masqué au modèle dans cet essai, pas indépendant de tout développement humain.

Deux graines de génération proposées : 0 et 1, température 0,2 ; noter si le serveur n'honore pas la graine. Un programme initial commun aux deux branches par fenêtre/graine, puis :

- branche vérifiée : au plus deux révisions, chacune reçoit seulement le premier contre-exemple du préfixe et sa couverture ;
- branche contrôle : au plus deux révisions, demande neutre de relire la règle avec le même préfixe, sans résultat du vérificateur.

Maximum : 20 requêtes, 4096 tokens générés par requête, un appel à la fois. Tous les programmes, erreurs, latences et usages réels sont conservés. Ce contraste ne contrôle pas exactement la longueur du prompt ; il mesure une boucle complète. Aucun gain causal dû au seul contre-exemple n'est revendiqué sans témoin à tokens égaux.

## Empêcher une mesure trompeuse

Le modèle doit écrire `predire(grid, action)` et d'éventuelles petites fonctions pures. Ne pas lui donner accès à `history`, `current_frame`, aux images attendues, aux fichiers ou au SDK dans son prédicteur. Vérifier le sous-ensemble de code accepté avant exécution dans le subprocess sandbox existant ; timeout obligatoire. Le programme évalué reçoit une copie de l'image précédente et l'action, jamais l'image suivante. Les révisions ne voient que le préfixe. Les grilles sont conservées en entier ; le score distingue erreurs de dimensions et de pixels. Exécuter les modèles sur suffixe une fois les révisions terminées ; ne pas corriger après lecture du suffixe.

Un premier test technique ne peut être lancé avant que le lanceur réalisant ces conditions soit prêt et vérifié. Ne pas lancer la campagne C' historique à sa place.

## Décision

Rapporter par fenêtre/graine : compilations, appels au vérificateur, erreurs détectées, transitions exactes du préfixe/suffixe et pixels erronés ; coût total incluant les échecs. Une règle identité est le contrôle trivial. Si l'outil ne permet pas de produire une règle utilisable ou si la correction ne dépasse jamais le contrôle sur suffixe, ne pas prolonger automatiquement.

Si effet positif : préparer ensuite une mesure interactive appariée sur jeux publics autorisés, même état initial, deux variantes immuables, budget et graines annoncés. Ce deuxième protocole doit être écrit avant ses actions. Le succès de l'étape 1 ne certifie ni but, ni plan, ni victoire, ni transférabilité aux jeux cachés.
