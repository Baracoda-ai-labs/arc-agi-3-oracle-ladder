# SPDX-License-Identifier: Apache-2.0 OR CC-BY-4.0
def chrys_verifier(predire, debut=0, fin=None, bord=0):
    """Replay a PURE predire(grid, action) on observed final frames of the CURRENT level.

    No game actions should be called from predire. This runs in the existing REPL
    sandbox, not an additional security boundary. Default: compare ALL cells.
    An explicitly requested border is excluded and reported, never certified.
    One-step replay is evidence on recorded inputs, not proof of a full rollout
    or of a goal. Inspect premiere_contradiction and coverage before planning.
    """
    def champ(x, key):
        return x.get(key) if isinstance(x, dict) else getattr(x, key, None)

    def grille(frame):
        value = champ(frame, "ascii")
        if isinstance(value, str):
            value = value.splitlines()
        if not isinstance(value, (list, tuple)) or not value:
            return None
        try:
            rows = [list(row) for row in value]
        except TypeError:
            return None
        if not rows[0] or any(len(row) != len(rows[0]) for row in rows):
            return None
        if any(not isinstance(cell, str) or len(cell) != 1 for row in rows for cell in row):
            return None
        return rows

    if not isinstance(bord, int) or isinstance(bord, bool) or bord < 0:
        raise ValueError("bord must be a non-negative integer")
    if not isinstance(debut, int) or debut < 0 or (fin is not None and (not isinstance(fin, int) or fin < debut)):
        raise ValueError("invalid replay interval")
    niveau = champ(current_frame, "level")
    justes, total, premiere, prec = 0, 0, None, None
    exclus, pixels, masques = {}, 0, 0
    def exclure(raison):
        exclus[raison] = exclus.get(raison, 0) + 1
    for pas, h in enumerate(history):
        f = champ(h, "frame")
        act = str(champ(h, "action") or "")
        res = dict(champ(h, "result") or {})
        g1 = grille(f)
        niv = champ(f, "level")
        reset = act.upper() == "RESET" or res.get("action_name") == "RESET" or res.get("automatic")
        terminal = bool(res.get("game_over") or res.get("level_completed") or res.get("run_complete"))
        raison = None
        if niveau is None or niv != niveau:
            raison = "autre_niveau_ou_niveau_inconnu"
        elif g1 is None:
            raison = "grille_invalide"
        elif reset or terminal:
            raison = "frontiere_ou_terminal"
        elif prec is None or prec[1] != niv:
            raison = "sans_predecesseur_du_niveau"
        elif not act:
            raison = "sans_action"
        elif pas < debut or (fin is not None and pas >= fin):
            raison = "hors_intervalle"
        elif len(g1) <= 2 * bord or len(g1[0]) <= 2 * bord:
            raison = "zone_comparee_vide"
        if raison:
            exclure(raison)
        else:
            total += 1
            erreur, p = None, None
            try:
                p = [list(row) for row in predire([row[:] for row in prec[0]], act)]
                if len(p) != len(g1) or any(len(row) != len(g1[0]) for row in p):
                    erreur = "dimensions_predites_differentes"
                elif any(not isinstance(cell, str) or len(cell) != 1 for row in p for cell in row):
                    erreur = "cellules_predites_invalides"
            except Exception as exc:
                erreur = type(exc).__name__ + ": " + str(exc)[:120]
            fausses = []
            if erreur is None:
                pixels += (len(g1) - 2 * bord) * (len(g1[0]) - 2 * bord)
                masques += len(g1) * len(g1[0]) - (len(g1) - 2 * bord) * (len(g1[0]) - 2 * bord)
                fausses = [(r, c, p[r][c], g1[r][c])
                           for r in range(bord, len(g1) - bord)
                           for c in range(bord, len(g1[0]) - bord) if p[r][c] != g1[r][c]]
            if erreur is None and not fausses:
                justes += 1
            elif premiere is None:
                premiere = {"pas": pas, "action": act, "erreur": erreur,
                            "cases_fausses": fausses[:5], "n_cases_fausses": len(fausses),
                            "dimensions_observees": [len(g1), len(g1[0])],
                            "dimensions_predites": [len(p), sorted(set(len(row) for row in p))] if p is not None else None}
        # RESET frame is a valid new starting observation; a terminal is not.
        prec = (g1, niv) if g1 is not None and niv == niveau and not terminal else None
    return {"transitions": total, "exactes": justes,
            "exactitude": round(justes / total, 3) if total else None,
            "premiere_contradiction": premiere,
            "niveau": niveau, "transitions_exclues": exclus,
            "pixels_compares": pixels, "pixels_masques": masques,
            "portee": "images_finales_completes" if bord == 0 else "interieur_seulement",
            "statut": "non_evalue" if not total else "contredit" if justes < total else "compatible_sur_transitions_testees",
            "but_verifie": False, "rollout_verifie": False}
