"""Bounded model repair experiment. No SDK; reference outputs never enter code sandbox.

Uses the existing Franzen subprocess sandbox and an OpenAI-compatible endpoint.
This tests the server model on recorded observations, not a full ToolAgent game.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

BUILTINS = set('range len list tuple dict set str int float bool abs min max sum any all enumerate zip sorted reversed next round ValueError'.split())
METHODS = set('append extend insert pop remove clear copy index count sort reverse get keys values items setdefault update add discard union intersection difference split join replace startswith endswith strip'.split())
FORBIDDEN = set('history current_frame action actions globals locals vars eval exec compile open input print getattr setattr delattr type object super __builtins__'.split())

def validate(source):
    if len(source)>20000:raise ValueError('source too long')
    tree=ast.parse(source)
    if not tree.body or any(not isinstance(n,ast.FunctionDef) for n in tree.body):
        raise ValueError('only function definitions are accepted')
    funcs={n.name for n in tree.body}
    if 'predire' not in funcs:raise ValueError('missing predire(grid, action)')
    # action is permitted as a parameter value, never as the live SDK function.
    forbidden=FORBIDDEN-{'action'}
    bound={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
    bound|={n.arg for n in ast.walk(tree) if isinstance(n,ast.arg)}
    if (funcs|bound)&forbidden or any(n.startswith('_') for n in funcs|bound):
        raise ValueError('reserved name')
    for n in ast.walk(tree):
        if isinstance(n,(ast.Import,ast.ImportFrom,ast.ClassDef,ast.Global,ast.Nonlocal,ast.Lambda,ast.With,ast.AsyncWith,ast.AsyncFunctionDef)):
            raise ValueError('unsupported construct '+type(n).__name__)
        if isinstance(n,ast.FunctionDef):
            if n.decorator_list or n.returns or any(a.annotation for a in n.args.args+n.args.kwonlyargs+n.args.posonlyargs):
                raise ValueError('decorators and annotations are not accepted')
            if any(not isinstance(x,ast.Constant) for x in n.args.defaults+[x for x in n.args.kw_defaults if x is not None]):
                raise ValueError('defaults must be constants')
        if isinstance(n,ast.Name) and (n.id in forbidden or n.id.startswith('_') or n.id not in BUILTINS|funcs|bound):
            raise ValueError('unknown or forbidden name '+n.id)
        if isinstance(n,ast.Attribute) and (n.attr not in METHODS or not isinstance(n.ctx,ast.Load)):
            raise ValueError('unsupported attribute '+n.attr)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='action':
            raise ValueError('game actions are forbidden')
    return source

def extract(text):
    blocks=re.findall(r'```(?:python)?\s*\n(.*?)```',text,re.S)
    return validate(blocks[-1].strip() if blocks else text.strip())

def evaluate(source,transitions,sandbox):
    try:validate(source)
    except (SyntaxError,ValueError) as e:
        return {'exactes':0,'total':len(transitions),'erreur':str(e),'predictions':None}
    inputs=[(x['before'],x['action']) for x in transitions]
    # Only BEFORE images/actions are sent to the child. Expected AFTER images
    # stay in this parent process, not in history, current_frame or globals.
    code=source+'\nimport json\nprint(json.dumps([predire(g,a) for g,a in '+repr(inputs)+']))'
    def no_action(*args,**kwargs):raise RuntimeError('SDK disabled for replay')
    result=sandbox(code=code,timeout_seconds=5,initial_state={'history':[],'current_frame':None},action_handler=no_action,kept_functions=[])
    if result.get('error'):
        return {'exactes':0,'total':len(transitions),'erreur':result['error'],'predictions':None}
    try:
        predicted=json.loads(result['stdout'].strip())
        if not isinstance(predicted,list) or len(predicted)!=len(transitions):raise ValueError('wrong batch size')
    except (ValueError,KeyError) as e:
        return {'exactes':0,'total':len(transitions),'erreur':str(e),'predictions':None}
    good=0;counter=None
    for i,(p,t) in enumerate(zip(predicted,transitions)):
        target=t['after']
        if p==target:good+=1
        elif counter is None:
            wrong=[]
            valid=isinstance(p,list) and len(p)==len(target) and all(isinstance(r,list) and len(r)==len(target[0]) for r in p)
            if valid:
                wrong=[(r,c,p[r][c],target[r][c]) for r in range(len(target)) for c in range(len(target[r])) if p[r][c]!=target[r][c]]
            counter={'transition':i,'step':t['step'],'action':t['action'],'dimensions_valides':valid,'cases_fausses':wrong[:8]}
    return {'exactes':good,'total':len(transitions),'premiere_contradiction':counter,'predictions':predicted}

def prepare(stem,out):
    import numpy as np
    rows=json.loads(stem.with_suffix('.json').read_text())['rows']
    with np.load(stem.with_suffix('.npz')) as z:images=z['images'].copy()
    assert len(images)==len(rows)+1 and len(rows)>=105
    names={1:'UP',2:'DOWN',3:'LEFT',4:'RIGHT',5:'SPACE',7:'ACTION7'}
    def tr(step):
        a=rows[step-1]['action']
        if not isinstance(a,int) or a not in names:raise ValueError('window contains unsupported action')
        grid=lambda g:[[format(int(v),'x') for v in row] for row in g]
        return {'step':step,'before':grid(images[step-1]),'action':names[a],'after':grid(images[step])}
    cases=[]
    for name,start in [('A',0),('B',82)]:
        cases.append({'name':name,'train':[tr(i) for i in range(start+1,start+12)],'test':[tr(i) for i in range(start+12,start+24)]})
    out.write_text(json.dumps({'trace_sha256':hashlib.sha256(stem.with_suffix('.npz').read_bytes()).hexdigest(),'cases':cases},separators=(',',':')))

def run(args):
    import requests
    sys.path.insert(0,str(args.harnais))
    from inference.agent.python_tool_sandbox import run_sandboxed_python
    args.output.mkdir(parents=True,exist_ok=False)
    cases=json.loads(args.cases.read_text())
    started=time.monotonic();calls=0
    def ask(messages,seed,label):
        nonlocal calls
        if calls>=20 or time.monotonic()-started>3600:raise RuntimeError('request/time budget exhausted')
        payload={'model':args.model,'messages':messages,'temperature':0.2,'seed':seed,'max_tokens':4096}
        calls+=1;t=time.monotonic()
        # No automatic retries: every request is counted, including failures.
        response=requests.post(args.base_url.rstrip('/')+'/chat/completions',json=payload,timeout=180)
        record={'label':label,'request':payload,'http_status':response.status_code,'seconds':time.monotonic()-t}
        try:record['response']=response.json()
        except ValueError:record['response_text']=response.text[:20000]
        (args.output/f'{calls:02d}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
        response.raise_for_status()
        return record['response']['choices'][0]['message']['content']
    system=('Write a pure Python predire(grid, action) returning the next grid of one-character cells. '
            'The prompt encodes each row as a string for compactness; your function receives lists of lists of one-character strings. '
            'Return only Python function definitions in a code fence. No imports, files, history, current_frame, '
            'globals, introspection or game actions. Helpers, loops, comprehensions, arithmetic and standard '
            'list/dict/set/string methods are allowed. Infer a rule from the supplied transitions. '
            'Do not hardcode an expected output table. All cells including border are evaluated.')
    summary=[]
    for case in cases['cases']:
        # Intentionally build the prompt ONLY from the training prefix.
        compact=[{**t,'before':[''.join(row) for row in t['before']],
                  'after':[''.join(row) for row in t['after']]} for t in case['train']]
        prefix=json.dumps(compact,separators=(',',':'))
        for seed in (0,1):
            initial=[{'role':'system','content':system},{'role':'user','content':'Observed transitions: '+prefix}]
            text=ask(initial,seed,f'{case["name"]}/{seed}/initial')
            for branch in ('verified','control'):
                messages=initial+[{'role':'assistant','content':text}];current=text;source=''
                for revision in range(3):
                    try:source=extract(current);train=evaluate(source,case['train'],run_sandboxed_python)
                    except (SyntaxError,ValueError) as e:source='';train={'exactes':0,'total':len(case['train']),'erreur':str(e)}
                    summary.append({'case':case['name'],'seed':seed,'branch':branch,'revision':revision,'source':source,'train':train})
                    if revision==2:break
                    feedback={k:v for k,v in train.items() if k!='predictions'}
                    prompt=('Verifier result on the supplied training transitions: '+json.dumps(feedback)+'. Repair your rule.'
                            if branch=='verified' else 'Review your rule against the supplied training transitions and return your revised rule.')
                    messages.append({'role':'user','content':prompt})
                    current=ask(messages,seed,f'{case["name"]}/{seed}/{branch}/{revision+1}')
                    messages.append({'role':'assistant','content':current})
                # No test results sent back to model, even on failure.
                summary[-1]['test']=evaluate(source,case['test'],run_sandboxed_python)
                (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    (args.output/'manifest.json').write_text(json.dumps({'requests':calls,'seconds':time.monotonic()-started,'trace_sha256':cases['trace_sha256'],'cases_sha256':hashlib.sha256(args.cases.read_bytes()).hexdigest(),'real_sdk_actions':0,'full_franzen_agent':False},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare');p.add_argument('--trace',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p=sub.add_parser('run');p.add_argument('--cases',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--harnais',type=Path,required=True);p.add_argument('--base-url',required=True);p.add_argument('--model',default='flashnext')
    args=ap.parse_args()
    prepare(args.trace,args.output) if args.command=='prepare' else run(args)
