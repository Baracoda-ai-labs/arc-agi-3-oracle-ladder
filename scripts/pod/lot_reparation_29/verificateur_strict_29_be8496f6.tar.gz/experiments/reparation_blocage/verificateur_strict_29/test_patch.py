import ast
import os
from pathlib import Path
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from patcher import transformer

LEGACY = Path('/Users/ts/models/reprise_local/chrysalide/arc3/outils_repl.py')

class Tests(unittest.TestCase):
    def load(self, source):
        ns={}
        exec(compile(source,'trusted_local_tools','exec'),ns)
        return ns

    def test_off_preserves_sources_and_prompt(self):
        s=LEGACY.read_text()
        with patch.dict(os.environ,{'CHRYS_VERIFIER_STRICT':'0','CHRYS_VERIFIER':'0','CHRYS_OUTILS':'1'}):
            a,b=self.load(s),self.load(transformer(s))
            self.assertEqual(a['SOURCES'],b['SOURCES'])
            self.assertEqual(a['ligne_tour'](SimpleNamespace()),b['ligne_tour'](SimpleNamespace()))

    def test_on_replaces_old_verifier_only_once(self):
        with patch.dict(os.environ,{'CHRYS_VERIFIER_STRICT':'1','CHRYS_VERIFIER':'1','CHRYS_OUTILS':'1'}):
            b=self.load(transformer(LEGACY.read_text()))
            self.assertEqual(len(b['SOURCES']),5)
            functions=[ast.parse(s).body for s in b['SOURCES']]
            self.assertTrue(all(len(f)==1 and isinstance(f[0],ast.FunctionDef) for f in functions))
            self.assertEqual(sum(f[0].name=='chrys_verifier' for f in functions),1)
            self.assertIn('counterexample',b['ligne_tour'](SimpleNamespace())[-1])

    def test_idempotence(self):
        s=transformer(LEGACY.read_text())
        self.assertEqual(transformer(s),s)

if __name__=='__main__':unittest.main()
