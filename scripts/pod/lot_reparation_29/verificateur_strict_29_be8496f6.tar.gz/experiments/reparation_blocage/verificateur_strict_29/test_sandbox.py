"""Uses Franzen's actual subprocess REPL, no model and no SDK."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0,'/Users/ts/models/chrysalide3/tiers/arc-agi-3-solution/ARC3-Inference')
from inference.agent.python_tool_sandbox import run_sandboxed_python
from inference.agent.runtime_state import Frame, HistoryEntry
from inference.agent.tool_agent import _ascii_frame_view_payload, _ascii_history_view_payload

class Tests(unittest.TestCase):
    def test_real_retained_function_executes_and_returns_counterexample(self):
        source=Path(__file__).with_name('verifier_source.py').read_text()
        f0=Frame(((0,0),(0,0)),0,1)
        f1=Frame(((1,0),(0,0)),1,1)
        called=[]
        def forbidden(*args,**kwargs):
            called.append(True)
            raise AssertionError('No SDK action permitted in this test')
        result=run_sandboxed_python(
            code='def predire(g, a):\n    return g\nprint(chrys_verifier(predire))',
            timeout_seconds=5,
            initial_state={'current_frame':_ascii_frame_view_payload(f1),'history':_ascii_history_view_payload([HistoryEntry('',f0),HistoryEntry('RIGHT',f1)])},
            action_handler=forbidden,kept_functions=[source])
        self.assertFalse(result.get('error'),result)
        self.assertIn('contredit',result['stdout'])
        self.assertIn('cases_fausses',result['stdout'])
        self.assertEqual(called,[])

if __name__=='__main__':unittest.main()
