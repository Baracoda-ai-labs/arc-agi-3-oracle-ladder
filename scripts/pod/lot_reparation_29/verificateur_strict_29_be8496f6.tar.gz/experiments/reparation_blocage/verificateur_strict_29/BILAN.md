# Vérificateur de programmes : correction isolée du 29 octobre

Le vérificateur existant `chrys_verifier` de `outils_repl.py` était déjà disponible sous CHRYS_VERIFIER. Ce chantier ne revendique pas son invention. L'ancien essai C' (CHRYS_AUDIT_PREDIRE) doit être consulté avant de répéter une mesure LLM ; confirmation demandée à Claude.

## Défauts reproduits et correction

- Une grille trop petite pour la bordure implicite de quatre cases ne produisait aucune comparaison, mais le résultat pouvait être déclaré exact. La variante renvoie `non_evalue`.
- Une prédiction de dimensions différentes pouvait passer si sa partie comparée coïncidait. Les dimensions sont désormais contrôlées avant les pixels.
- Un changement de niveau n'était pas explicitement exclu. Le rejeu est limité au niveau courant et aux transitions non terminales ; RESET crée un nouveau point de départ.
- Par défaut tous les pixels finaux sont comparés. Une bordure explicitement demandée est déclarée comme couverture partielle ; elle n'est pas validée comme un masque de jauge appris.
- Le résultat donne couverture, première contradiction, type d'erreur et nombre de pixels comparés. Il distingue ce rejeu à un pas d'un rollout et d'une condition de victoire, qui ne sont pas vérifiés.

Le prédicteur doit rester pur. Il s'exécute dans le REPL subprocess existant, pas dans une nouvelle frontière de sécurité ; le vérificateur ne garantit pas l'absence d'effets de bord d'un Python arbitraire. Aucun prédicteur inconnu n'est exécuté hors du sandbox par ces tests.

## Preuves

13 tests de correction et de branchement passent, plus un test dans le vrai subprocess REPL de Franzen (14 au total). Le dernier utilise les sérialiseurs ASCII du harnais et confirme un retour de contre-exemple sans appel d'action. Le harnais émet des ResourceWarning de pipes non fermés dans ce test ; pas de changement du harnais pour ce warning.

Le rejeu de 114 transitions finales sk48 conserve le verdict de la règle identité : 23/114 exactes, première contradiction au pas 1. Ce n'est pas une nouvelle règle ni un gain. Un défaut volontaire de dimension (65 lignes au lieu de 64) appliqué à l'observation inchangée du pas 12 est accepté à tort par l'ancien vérificateur, refusé par la variante. Cette injection de défaut utilise une vraie observation, mais n'est pas un programme produit par le LLM.

`rejeu_sk48.json` inclut le SHA de l'archive et les résultats. Métadonnées reconstruites à partir d'un niveau SDK : ce n'est pas un journal Franzen natif. Zéro nouvelle action SDK, zéro victoire revendiquée.

## Raccord réutilisé

`patcher.py <COPIE_DU_HARNAIS>` se pose après `patcher_outils.py`. Il ajoute un remplacement optionnel de la fonction retenue et sa description, avec `CHRYS_OUTILS=1`, `ARC3_PERSISTENT_FUNCTIONS=1` et `CHRYS_VERIFIER_STRICT=1`. Le canal REPL, les fonctions retenues et le sandbox sont ceux qui existent déjà. CHRYS_VERIFIER_STRICT absent ou zéro conserve la liste des sources et le texte des outils à l'identique dans le test local. Cela ne prouve pas une partie identique. Garder CHRYS_VERIFIER=0 dans la variante pour ne pas confondre les options.

Ne pas patcher le carnet ROF en cours ni le candidat figé. Un patcher_outils relancé après ce patch peut écraser la variante ; contrôler son tag avant test.

## Étape GPU proposée à Claude

Infrastructure et frais restent pilotés par Claude, dans le plafond de 100 euros autorisé. Réutiliser serveur/poids/copie du harnais déjà éprouvés ; aucun téléchargement Mac ni entraînement.

1. Relire résultat C' s'il existe. Vérifier sur serveur cible que l'outil est visible et réellement appelé, que son retour de contradiction entre dans le tour suivant et que les tokens/temps sont enregistrés.
2. Petit test mécaniste, avant campagne : sur observations de développement autorisées, demander un prédicteur borné à une primitive, obtenir un contre-exemple puis une correction, et tester la correction sur un suffixe non fourni. Distinguer synthèse depuis observations et mémorisation du suffixe. Une amélioration sur ce test n'est pas une victoire ARC.
3. Si la boucle fonctionne, protocole figé comparant la référence choisie et la variante sur mêmes jeux/graines/budgets ; conserver coûts des requêtes, refus et temps. Une référence contemporaine est nécessaire pour attribuer un gain. Ne pas confondre égalité du budget maximal et égalité du coût réellement consommé. Le contrôle à tokens égaux demande encore le tokenizer cible.
4. Promouvoir seulement après gain réel et absence de régression critique. Si l'outil n'est pas appelé ou si les règles restent réfutées, ne pas dépenser le reste du budget sur une campagne inchangée.

Prochain développement à forte valeur : observer effectivement si le LLM exploite le contre-exemple. Ne pas multiplier les métriques locales en les présentant comme une amélioration du score.

## Lanceur de faisabilité livré

`essai_reparation.py` prépare les deux fenêtres fixées dans PROTOCOLE_POD.md puis réalise au plus 20 requêtes sur le serveur compatible OpenAI. Il teste directement le modèle servi, pas une partie complète du ToolAgent RO. Le retour de contre-exemple est injecté par le lanceur : le test ne mesure donc pas la décision spontanée du modèle d'appeler un outil. Cette distinction doit rester dans le rapport.

La comparaison des sorties est faite dans le processus parent : le subprocess prédicteur reçoit seulement les images avant/actions, jamais les images attendues. Un sous-ensemble AST exclut imports, accès à history/current_frame, introspection, exécution au niveau module et appels SDK ; le sandbox de Franzen impose le délai. Ce filtre réduit le langage accepté et peut lui-même provoquer des refus : ils sont comptés comme échecs, pas masqués. Il ne remplace pas une revue de sécurité générale.

Six tests supplémentaires passent, dont un protocole entier à serveur simulé (20 requêtes, aucun réseau) et un vrai subprocess sandbox. Les réponses de suffixe ne figurent pas dans les requêtes du test. Aucun résultat LLM réel ni SDK. `cas_sk48.json` contient les données de développement déjà acquises ; les prompts encodent les lignes comme chaînes pour réduire leur volume. Temps maximal du lanceur 1h, timeout requête180s, zéro retry automatique ; après erreur la sortie conserve les requêtes déjà tentées.

Commande pod, depuis ce dossier :

```sh
python essai_reparation.py run --cases cas_sk48.json --output /workspace/runs/reparation_predire_29_1 --harnais /workspace/harnais --base-url http://127.0.0.1:8011/v1 --model flashnext
```

Le répertoire de sortie doit être nouveau. Le chemin réel du harnais et la variante de poids doivent être confirmés par Claude. Un modèle répondant du code hors du sous-ensemble autorisé ne valide pas la boucle ; ne pas relaxer le filtre après lecture des suffixes. Ne pas lancer d'action réelle depuis ce pilote.
