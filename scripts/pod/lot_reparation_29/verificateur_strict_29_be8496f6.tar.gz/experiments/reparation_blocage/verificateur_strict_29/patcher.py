"""Opt-in strict verifier, installed only into an explicit disposable RO harness.

Reuse the existing retained-functions channel; no new tool protocol or SDK call.
The frozen notebook is not edited. Run after the existing patcher_outils.
"""
from pathlib import Path
import sys

TAG = '# CHRYSALIDE-VERIFIER-STRICT-29'

def transformer(source):
    if TAG in source:
        return source
    rule = (Path(__file__).with_name('verifier_source.py')).read_text()
    suffix = '\n' + TAG + '\n'
    suffix += 'if __import__("os").environ.get("CHRYS_VERIFIER_STRICT", "0") == "1":\n'
    suffix += '    SOURCES = [s for s in SOURCES if not s.startswith("def chrys_verifier(")]\n'
    suffix += f'    SOURCES.append({rule!r})\n'
    suffix += '    _ligne_tour_sans_verifier_strict = ligne_tour\n'
    suffix += '    def ligne_tour(agent):\n'
    suffix += '        parts = list(_ligne_tour_sans_verifier_strict(agent))\n'
    suffix += '        if __import__("os").environ.get("CHRYS_OUTILS", "0") == "1":\n'
    suffix += '            parts.append("CPU hypothesis check: define a pure predire(grid, action) without game actions, then call chrys_verifier(predire). It returns coverage and the first counterexample on current-level recorded final frames. Default compares every cell. Repair a contradicted rule before relying on it; replay compatibility is not a verified goal or proof about unseen states.")\n'
    suffix += '        return parts\n'
    result = source + suffix
    compile(result,'outils_repl.py','exec')
    return result

if __name__ == '__main__':
    root = Path(sys.argv[1])
    target = root/'inference/chrysalide_arc3/outils_repl.py'
    original = target.read_text()
    updated = transformer(original)
    if updated != original:
        target.write_text(updated)
    print('patched' if updated != original else 'already patched')
