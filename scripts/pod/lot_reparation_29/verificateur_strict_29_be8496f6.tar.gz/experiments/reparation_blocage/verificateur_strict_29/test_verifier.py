import unittest
import verifier_source as v

def frame(rows, level=1):
    return {'ascii': rows, 'level': level}

def entry(rows, action='', level=1, **result):
    return {'frame': frame(rows, level), 'action': action, 'result': result}

class Tests(unittest.TestCase):
    def run_history(self, history, predict=lambda g,a:g, **kwargs):
        v.history = history
        v.current_frame = history[-1]['frame']
        return v.chrys_verifier(predict, **kwargs)

    def test_small_grid_contradiction_not_hidden(self):
        r = self.run_history([entry(['00','00']),entry(['10','00'],'RIGHT')])
        self.assertEqual(r['statut'],'contredit')
        self.assertEqual(r['premiere_contradiction']['cases_fausses'],[(0,0,'0','1')])

    def test_empty_comparison_abstains(self):
        r = self.run_history([entry(['00']),entry(['10'],'RIGHT')],bord=4)
        self.assertIsNone(r['exactitude'])
        self.assertEqual(r['statut'],'non_evalue')

    def test_extra_prediction_rows_rejected(self):
        r = self.run_history([entry(['00']),entry(['00'],'RIGHT')],lambda g,a:g+[['0','0']])
        self.assertEqual(r['exactes'],0)
        self.assertEqual(r['premiere_contradiction']['erreur'],'dimensions_predites_differentes')

    def test_new_level_does_not_form_transition(self):
        r = self.run_history([entry(['00'],level=1),entry(['11'],'RIGHT',level=2)])
        self.assertEqual(r['transitions'],0)

    def test_reset_is_new_start_not_a_rule(self):
        r = self.run_history([entry(['00']),entry(['11'],'RESET'),entry(['11'],'RIGHT')])
        self.assertEqual(r['transitions'],1)
        self.assertEqual(r['exactes'],1)

    def test_terminal_not_inferred_from_grid(self):
        r = self.run_history([entry(['00']),entry(['00'],'RIGHT',game_over=True),entry(['00'],'RESET'),entry(['00'],'LEFT')])
        self.assertEqual(r['transitions'],1)
        self.assertFalse(r['but_verifie'])

    def test_interval_only_counts_selected_transitions(self):
        r = self.run_history([entry(['00']),entry(['11'],'RIGHT'),entry(['11'],'LEFT')],debut=2,fin=3)
        self.assertEqual((r['transitions'],r['exactes']),(1,1))

    def test_mask_is_explicit_partial_evidence(self):
        r = self.run_history([entry(['000']*3),entry(['100','000','000'],'RIGHT')],bord=1)
        self.assertEqual(r['exactes'],1)
        self.assertEqual(r['portee'],'interieur_seulement')
        self.assertEqual(r['pixels_masques'],8)
        self.assertFalse(r['rollout_verifie'])

    def test_predictor_exception_is_counterexample(self):
        def bad(g,a):raise RuntimeError('bad rule')
        r = self.run_history([entry(['00']),entry(['00'],'RIGHT')],bad)
        self.assertEqual(r['statut'],'contredit')

    def test_predictor_cannot_mutate_recorded_input(self):
        h=[entry(['00']),entry(['00'],'RIGHT')]
        def mut(g,a):g[0][0]='1';return g
        self.run_history(h,mut)
        self.assertEqual(h[0]['frame']['ascii'],['00'])

if __name__=='__main__':unittest.main()
