"""Replay existing final frames, no SDK; this is not a native Franzen journal."""
import ast
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import verifier_source as strict

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--trace',type=Path,required=True)
    ap.add_argument('--legacy',type=Path,required=True)
    ap.add_argument('--sortie',type=Path,required=True)
    args=ap.parse_args()
    rows=json.loads(args.trace.with_suffix('.json').read_text())['rows']
    with np.load(args.trace.with_suffix('.npz')) as z:
        images=z['images'].copy()
    assert len(images)==len(rows)+1
    def frame(g):return {'ascii':[''.join(format(int(c),'x') for c in row) for row in g], 'level':1}
    names={1:'UP',2:'DOWN',3:'LEFT',4:'RIGHT',5:'SPACE',7:'ACTION7'}
    h=[{'frame':frame(images[0]),'action':'','result':{}}]
    for row,g in zip(rows,images[1:]):
        a=row['action']
        h.append({'frame':frame(g),'action':names.get(a,str(a)) if isinstance(a,int) else str(a), 'result':{}})
    # Metadata are reconstructed from the single-level archive; no terminal
    # interpretation is inferred. This experiment does not cover real RESETs.
    source=next(ast.literal_eval(n.value) for n in ast.parse(args.legacy.read_text()).body
                if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERIFIER' for t in n.targets))
    legacy={'history':h,'current_frame':h[-1]['frame']}
    exec(compile(source,'trusted_legacy_verifier','exec'),legacy)
    strict.history=h;strict.current_frame=h[-1]['frame']
    identity=lambda g,a:g
    report={'trace_sha256':hashlib.sha256(args.trace.with_suffix('.npz').read_bytes()).hexdigest(),
            'actions':len(rows),'sdk_actions_new':0,'native_franzen_journal':False,
            'legacy_identity':legacy['chrys_verifier'](identity),
            'strict_identity':strict.chrys_verifier(identity)}
    idle=next(i for i in range(1,len(h)) if h[i]['frame']==h[i-1]['frame'])
    pair=h[idle-1:idle+1]
    legacy['history']=pair
    strict.history=pair;strict.current_frame=pair[-1]['frame']
    oversized=lambda g,a:g+[['0']*len(g[0])]
    report['planted_wrong_dimensions']={'original_step':idle,
        'legacy':legacy['chrys_verifier'](oversized),
        'strict':strict.chrys_verifier(oversized)}
    args.sortie.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'actions':len(rows),'idle_step':idle,
                     'legacy_false_accept':report['planted_wrong_dimensions']['legacy']['exactitude'],
                     'strict_status':report['planted_wrong_dimensions']['strict']['statut']}))

if __name__=='__main__':main()
