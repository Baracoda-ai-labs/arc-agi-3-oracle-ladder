import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import essai_reparation as e

sys.path.insert(0,'/Users/ts/models/chrysalide3/tiers/arc-agi-3-solution/ARC3-Inference')
from inference.agent.python_tool_sandbox import run_sandboxed_python

IDENTITY='def predire(grid, action):\n    return [row[:] for row in grid]'

class Tests(unittest.TestCase):
    def test_allowed_pure_program(self):
        self.assertEqual(e.validate(IDENTITY),IDENTITY)

    def test_history_and_introspection_denied(self):
        for body in ('return history[-1]', 'return globals()', 'return grid.__class__', 'return current_frame', 'return open("x")', 'action("RIGHT")\n    return grid'):
            with self.subTest(body=body),self.assertRaises(ValueError):
                e.validate('def predire(grid, action):\n    '+body)

    def test_import_and_top_level_execution_denied(self):
        for source in ('import os\n'+IDENTITY, IDENTITY+'\npredire([], "UP")', 'def predire(grid, action):\n    import os\n    return grid'):
            with self.subTest(source=source),self.assertRaises(ValueError):e.validate(source)

    def test_expected_output_never_sent_to_sandbox(self):
        captured=[]
        def sandbox(**kwargs):
            captured.append(kwargs)
            return {'stdout':'[[["0"]]]'}
        r=e.evaluate(IDENTITY,[{'step':1,'before':[['0']],'action':'UP','after':[['SECRET']]}],sandbox)
        self.assertNotIn('SECRET',str(captured))
        self.assertEqual(r['exactes'],0)

    def test_actual_sandbox_predicts_without_history(self):
        r=e.evaluate(IDENTITY,[{'step':1,'before':[['0']],'action':'UP','after':[['1']]}],run_sandboxed_python)
        self.assertEqual(r['exactes'],0)
        self.assertEqual(r['premiere_contradiction']['cases_fausses'],[(0,0,'0','1')])

    def test_full_protocol_mock_server_no_test_feedback(self):
        calls=[]
        def post(url,json,timeout):
            calls.append(json)
            return SimpleNamespace(status_code=200,json=lambda:{'choices':[{'message':{'content':IDENTITY}}],'usage':{'total_tokens':1}},raise_for_status=lambda:None)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);cases=p/'cases.json'
            t={'step':1,'before':[['0']],'action':'UP','after':[['0']]}
            hidden={'step':2,'before':[['0']],'action':'UP','after':[['Ω']]}
            cases.write_text(json.dumps({'trace_sha256':'test','cases':[{'name':n,'train':[t],'test':[hidden]} for n in ('A','B')]}))
            args=SimpleNamespace(harnais=Path(sys.path[0]),cases=cases,output=p/'result',base_url='http://unused/v1',model='mock')
            with patch('requests.post',post):e.run(args)
            self.assertEqual(len(calls),20)
            self.assertNotIn('Ω',json.dumps(calls,ensure_ascii=False))
            report=json.loads((args.output/'summary.json').read_text())
            self.assertEqual(len(report),24)
            self.assertTrue(all(x['test']['exactes']==0 for x in report if 'test' in x))

if __name__=='__main__':unittest.main()
